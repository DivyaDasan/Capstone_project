import json
import boto3

#To add conditions to scanning and querying the table-import the boto3.dynamodb.conditions.Key and boto3.dynamodb.conditions.Attr classes.
from boto3.dynamodb.conditions import Key, Attr

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("product_table")

                
def lambda_handler(event, context):
    
    #event-dictonary-(contain the json data)
    
    #can see prints in monitor-cloudwatch
    print("++++hello+++++")
   
    #product-string;-get the prodname from API
    prod=event['prodname']  
    product=prod.lower()       
    
    #type-dict
    response = table.query(
    KeyConditionExpression=Key('prodname').eq(product)
      )
    
    #list-contain 1 item i.e a dict; this dict contain table data
    items = response['Items']
    
    #store the dict to dict1
    dict1=items[0]
    
    #delete the prodname in order to compare the prices using min()
    del dict1["prodname"]
    
    #find min price
    minval = min(dict1.values())
    
    #get key of minval i.e ecommerce site
    res = [key for key in dict1 if dict1[key] == minval]    #res is list -contain 1 item->site name
    
    return {"Code" : 200, "Offer_site":res[0]}