import pymysql
import boto3
import json 


client = boto3.client('secretsmanager')
response = client.get_secret_value(
    SecretId='cardoffersecret'
)

secretDict=json.loads(response['SecretString'])
print(secretDict)

connection = pymysql.connect(host=secretDict['host'],
                             user=secretDict['username'],
                             password=secretDict['password'],
                             database=secretDict['dbname'],
                             cursorclass=pymysql.cursors.DictCursor)

def lambda_handler(event, context):
   
    #website="Flipcart"
    #crd='credit'
   
    website=event['site']
    crd=event['card']
    site=website.lower()
    card=crd.lower()
    
    try:
     cursor = connection.cursor()
     
     if card=='credit':
         cursor.execute('SELECT * from credit_card_offers WHERE website=%s',site)
     else:
         cursor.execute('SELECT * from debit_card_offers WHERE website=%s',site)
    
     row = cursor.fetchone()
     if row is not None:
           response=row
     else:
        response="Not found"
     print(response)
    
    finally:
        connection.close()
        print("connection closed successfully")
    return response
   
