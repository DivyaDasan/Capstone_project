import boto3

s3_client = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")

table = dynamodb.Table("product_table")

def lambda_handler(event,context):
    #event-json document
    print(type(event))
    
    #get the bucket-name and file-name
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    s3_file_name = event['Records'][0]['s3']['object']['key']
    
    #get_object() returns a dictionary
    #the resp contain the items content type;last modified; body 
    resp = s3_client.get_object(Bucket=bucket_name,Key=s3_file_name)     #key should be in capital
   
    #data-string type
    #contain the file data
    data = resp['Body'].read().decode("utf-8")
    
    #product_details-list type
    #each line in data is an item in the list
    product_details = data.split("\n")
    
    for prod  in product_details:
        #prod-string type
        #each word in prod stored to list
        prod_data = prod.split(",")  
        
        if prod_data[0] != "productname":  #dont need the heading(productname,flipcart,amazone)
        #add to dynamodb
            try:
               table.put_item(
                    Item = {
                           "prodname"   :  prod_data[0],   #eg)samsung 
                           "amazon"     :  prod_data[1],   #price of samsung in amazon
                           "flipcart"   :  prod_data[2],
                           "jiomart"    :  prod_data[3]
                           }
                      )
            except Exception as e:
                    print("End of file")
    print("Item added successfully")
        
